# FOCUSED STUDY TRACKER — Cloud sync setup

## Supabase project
- URL: `https://lzytcwoqswdnujqvirnq.supabase.co`
- Client key: the publishable key is configured in `.env` for local builds.
- Never put a service-role/secret key in the app or website.

## Database
Run `supabase/schema.sql` once in the Supabase SQL Editor. The user confirmed the SQL Editor returned `Success. No rows returned` on 7 Nov 2026.

## Website cloud sync
`website/index.html` is the updated existing tracker with Supabase email/password sign-in, account creation, safe merge of browser-local progress into the signed-in account, manual sync, and automatic cloud saves after local changes.

Deploy the contents of `website/` to the same hosting location as the existing tracker. Then sign in/create the same email/password account on the website and in the app. The website keeps the original `msbteWinter2026TrackerV1` localStorage key and does not delete it.

## Important migration behavior
On first sign-in, the website reads the current browser's local tracker data, merges it with any existing cloud data (local values take precedence for matching keys), writes the merged result to Supabase, and retains the original local copy. This is how the saved checkboxes from the browser in which the tracker is currently used are migrated. Other browsers/devices' local-only data must be exported and imported on the device that holds it before signing in there.

## Native app
The native app uses the same Supabase URL/key in `.env`. Use `npm install`, then an EAS development/production build; Expo Go is not sufficient for the native widget extension. This source package is not itself an installable app binary.
