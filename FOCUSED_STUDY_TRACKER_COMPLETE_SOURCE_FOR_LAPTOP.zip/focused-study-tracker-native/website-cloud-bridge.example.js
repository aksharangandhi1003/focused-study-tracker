// Integrate into the existing website after adding Supabase JS and sign-in.
 // This is a migration bridge example, not a drop-in script until the website has Supabase auth.
 async function migrateExistingTrackerProgress(supabase, userId) {
   const key = 'msbteWinter2026TrackerV1';
   const raw = localStorage.getItem(key);
   if (!raw) return { migrated: false, reason: 'No local tracker data found' };
   const local = JSON.parse(raw);
   const { data: existing, error: readError } = await supabase
     .from('tracker_progress').select('progress').eq('user_id', userId).maybeSingle();
   if (readError) throw readError;
   const cloud = existing?.progress || {};
   const merged = {
     ...cloud, ...local,
     days: { ...(cloud.days || {}), ...(local.days || {}) },
     units: { ...(cloud.units || {}), ...(local.units || {}) },
     quiz: { ...(cloud.quiz || {}), ...(local.quiz || {}) },
     focus: { ...(cloud.focus || {}), ...(local.focus || {}) },
     extraTasks: [...(cloud.extraTasks || []), ...(local.extraTasks || [])]
   };
   const { error } = await supabase.from('tracker_progress')
     .upsert({ user_id: userId, progress: merged, updated_at: new Date().toISOString() });
   if (error) throw error;
   // Keep the original localStorage key as a safety copy; do not remove it.
   return { migrated: true };
 }
