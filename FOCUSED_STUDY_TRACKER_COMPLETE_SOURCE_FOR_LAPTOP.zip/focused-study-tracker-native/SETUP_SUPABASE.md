# Supabase setup — FOCUSED STUDY TRACKER

The project URL and publishable key have been added to `.env` for local builds.

## 1. Create the progress table

1. Open https://supabase.com/dashboard/project/lzytcwoqswdnujqvirnq/sql/new
2. Paste the contents of `supabase/schema.sql` into the SQL Editor.
3. Press **Run**.
4. Confirm that `public.tracker_progress` appears in Table Editor.

The SQL enables row-level security and limits each signed-in user to their own progress row.

## 2. Run the app locally

```bash
npm install
npx expo start
```

For a native development build, use the EAS build profiles in `eas.json` after installing and configuring EAS CLI.

## Security

The publishable key is intended for client-side apps. Never put a Supabase secret/service-role key in the app, website, or `.env` distributed with the app. Keep RLS enabled.

## Important migration note

The existing website's localStorage data is not automatically uploaded by this setup. Export a backup from the existing tracker first, then use the website cloud bridge/import workflow to migrate it after the website is updated to use the same Supabase project. Do not clear browser storage until the cloud copy has been verified.
