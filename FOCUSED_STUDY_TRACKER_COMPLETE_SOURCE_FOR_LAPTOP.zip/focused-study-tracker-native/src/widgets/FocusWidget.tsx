import { createWidget } from 'expo-widgets';
import { Column, Row, Text, LinearProgressIndicator } from '@expo/ui/jetpack-compose';
const FocusWidget = (props: { subject:string; topic:string; remaining:string; percent:number }) => {
  'widget';
  return <Column modifier={{padding:14}} spacing={8}>
    <Text>⏱ FOCUS SESSION</Text>
    <Text>{props.subject}</Text>
    <Text>{props.topic}</Text>
    <Text>{props.remaining} remaining</Text>
    <LinearProgressIndicator progress={props.percent/100}/>
  </Column>;
};
export default createWidget('FocusWidget',FocusWidget,{subject:'Ready to focus',topic:'Choose today\'s plan',remaining:'--:--',percent:0});
