import { createWidget } from 'expo-widgets';
import { Column, Row, Text, LinearProgressIndicator } from '@expo/ui/jetpack-compose';
const ProgressWidget = (props: { percent:number; completed:number; total:number; subject:string }) => {
  'widget';
  return <Column modifier={{padding:14}} spacing={8}>
    <Text>🌷 FOCUSED STUDY TRACKER</Text>
    <Text>{props.percent}% overall progress</Text>
    <LinearProgressIndicator progress={props.percent/100}/>
    <Row><Text>{props.completed}/{props.total} tasks</Text><Text>{props.subject}</Text></Row>
  </Column>;
};
export default createWidget('ProgressWidget',ProgressWidget,{percent:0,completed:0,total:0,subject:'Today'});
