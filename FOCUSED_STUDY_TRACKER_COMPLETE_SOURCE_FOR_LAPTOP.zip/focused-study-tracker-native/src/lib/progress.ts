import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from './supabase';
const LOCAL_KEY = 'focusedStudyTrackerProgressV1';
export type Progress = { days: Record<string, any>; units: Record<string, any>; quiz: Record<string, any>; extraTasks: any[]; focus: Record<string, any>; quizHistory: any[]; autoUnits?: Record<string, any> };
export const emptyProgress: Progress = { days:{}, units:{}, quiz:{}, extraTasks:[], focus:{}, quizHistory:[], autoUnits:{} };
export async function loadLocal(): Promise<Progress> {
  try { const raw=await AsyncStorage.getItem(LOCAL_KEY); return raw ? {...emptyProgress,...JSON.parse(raw)} : emptyProgress; } catch { return emptyProgress; }
}
export async function saveProgress(progress: Progress, userId?: string) {
  await AsyncStorage.setItem(LOCAL_KEY, JSON.stringify(progress));
  if (!userId) return;
  const { error } = await supabase.from('tracker_progress').upsert({ user_id:userId, progress, updated_at:new Date().toISOString() }, { onConflict:'user_id' });
  if (error) throw error;
}
export async function syncFromCloud(userId: string): Promise<Progress> {
  const local=await loadLocal();
  const { data, error }=await supabase.from('tracker_progress').select('progress,updated_at').eq('user_id',userId).maybeSingle();
  if(error) throw error;
  if(!data?.progress){ await saveProgress(local,userId); return local; }
  // Merge maps; union tasks by stable id; never replace local progress with empty defaults.
  const cloud=data.progress as Progress;
  const merged:Progress={
    ...emptyProgress,
    ...cloud,
    days:{...local.days,...cloud.days},
    units:{...local.units,...cloud.units},
    quiz:{...local.quiz,...cloud.quiz},
    focus:{...local.focus,...cloud.focus},
    autoUnits:{...local.autoUnits,...cloud.autoUnits},
    extraTasks:Array.from(new Map([...(local.extraTasks||[]),...(cloud.extraTasks||[])].map(x=>[x.id,x])).values()),
    quizHistory:[...(local.quizHistory||[]),...(cloud.quizHistory||[])].filter((x,i,a)=>a.findIndex(y=>JSON.stringify(y)===JSON.stringify(x))===i)
  };
  await saveProgress(merged,userId); return merged;
}
export async function signIn(email:string,password:string){return supabase.auth.signInWithPassword({email,password});}
export async function signUp(email:string,password:string){return supabase.auth.signUp({email,password});}
