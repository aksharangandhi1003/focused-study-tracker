# FOCUSED STUDY TRACKER

A pastel study planner app starter built with Expo React Native. The interface and source timetable are platform-neutral; the project can be built for supported devices after account setup.

## Included in this build
- Home dashboard with overall progress and the preserved 29 Oct–1 Dec 2026 timetable.
- Daily checklist with date navigation and personal task creation.
- Syllabus checklist for DT, SML, DSP and DBMS, preserving the supplied unit descriptions and marks.
- Interactive multiple-choice quiz using the supplied quiz bank and explanations.
- Focus timer that uses the selected date's planned hours; pause, resume and reset. Timer expiry does not mark tasks complete.
- Local progress storage, optional Supabase email authentication and cloud progress table with row-level security.
- Progress home-screen widget definition and a promotional thumbnail asset.

## Run locally
1. Install Node.js LTS.
2. In this folder run `npm install`.
3. Run `npx expo install --fix` to align native package versions with the installed Expo SDK.
4. Run `npx expo start` for development. A native development build is required for widgets; Expo Go does not load native widgets.
5. Use `npx expo prebuild` and a development build to test native functionality.

## Cloud sync setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. Copy `.env.example` to `.env` and fill `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
4. Use the same Supabase account in the website after the website has also been updated to use this cloud table.

Never put a Supabase `service_role` secret in a client app. The publishable key is intended for client-side use with Row Level Security enabled.

## Important current limitations
- This is a working source project, not an installed or store-published app binary.
- Cloud sync requires a real Supabase project and a matching website integration. The existing website still uses browser localStorage until its cloud bridge is installed.
- Existing private checkmarks are stored in the browser. Export a tracker backup from the website and retain it; the current project cannot read browser storage remotely.
- Widgets need native build testing and operating-system approval. Refresh cadence is controlled by the operating system.
- App-store publishing requires the developer's own signing and store accounts.
