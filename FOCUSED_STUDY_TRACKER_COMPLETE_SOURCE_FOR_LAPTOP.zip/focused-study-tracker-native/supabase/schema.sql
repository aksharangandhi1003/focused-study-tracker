create table if not exists public.tracker_progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  progress jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.tracker_progress enable row level security;
create policy "Users can read own tracker progress" on public.tracker_progress for select using (auth.uid() = user_id);
create policy "Users can insert own tracker progress" on public.tracker_progress for insert with check (auth.uid() = user_id);
create policy "Users can update own tracker progress" on public.tracker_progress for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
